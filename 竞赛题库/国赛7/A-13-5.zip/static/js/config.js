/* eslint-disable */
/*
* 配置说明
*   若是使用云平台提供接口服务，那么apiUrl 填入的是云平台接口服务地址，serverType值设置成1
*   否则只需修改apiUrl为提供接口服务的地址, serverType值设置成0即可。
* */
var SITE_CONFIG = {
  apiUrl: '', // 云平台接口服务地址  http://api.nlecloud.com
  serverType: 0 // 0：其他接口服务   1：云平台接口服务
}
